function showResults() {
  // Obtenha as respostas do quiz (exemplo simples)
  const answer1 = document.querySelector('input[name="q1"]:checked');

  // Adicione mais perguntas e respostas conforme necessário

  // Exemplo simples: Determine o estilo com base nas respostas
  let style = "Indefinido";
  if (answer1 && answer1.value === "vinho") {
      style = "Estilo Clássico Vinho";
  }

  // Adicione mais lógica conforme necessário

  // Exiba os resultados
  document.getElementById('result').innerText = style;
  document.getElementById('quiz-container').classList.add('hidden');
  document.getElementById('results-container').classList.remove('hidden');
}
